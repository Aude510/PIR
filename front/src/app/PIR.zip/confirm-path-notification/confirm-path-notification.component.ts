import { Component } from '@angular/core';

@Component({
  selector: 'app-confirm-path-notification',
  templateUrl: './confirm-path-notification.component.html',
  styleUrls: ['./confirm-path-notification.component.sass']
})
export class ConfirmPathNotificationComponent {

}
